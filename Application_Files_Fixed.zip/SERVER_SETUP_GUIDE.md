# Asset Tracker — Server-Backed Setup Guide

This replaces the old "sign in with Google from the browser" version. Now the browser never talks to Google directly — it talks to a small backend (a handful of Cloudflare Pages Functions) that holds each person's Google credentials securely and does the Drive work on their behalf.

**What this fixes, concretely:** no more hour-long token expiry, no more "OAuth client not found," no more Safari cookie weirdness with silent reconnects. Once someone signs in on a device, they stay signed in — genuinely, not just "for an hour" — until they explicitly sign out or Google revokes access.

**The one thing this can't route around:** if your OAuth consent screen is in "Testing" mode (required for anyone using a personal Gmail account rather than your Workspace domain), Google caps refresh tokens at 7 days regardless of what the server does, and caps you at 100 total users. Submitting for Google's verification removes both limits — see the note at the end.

---

## Why the hosting changes

Previously: GitHub Pages (static files only) + Google's client-side sign-in library. GitHub Pages can't run server code at all, so the new backend needs a different host — one that runs both the app's files *and* a few small server functions from the same web address. That's **Cloudflare Pages**, which is free at this scale and (bonus) can deploy straight from the same GitHub repo you already have, the same way GitHub Pages did.

Same domain for both matters for a real reason, not just convenience: it lets the sign-in session use a plain, ordinary cookie instead of a cross-site one — which is exactly the kind of cookie Safari doesn't quietly block, unlike what we were fighting before.

---

## A. Update the Google Cloud OAuth client

You're reusing the same OAuth client from before — just adding one field and grabbing one more value.

1. Go to **console.cloud.google.com** → your existing project → **APIs & Services → Credentials**.
2. Click your existing OAuth 2.0 Client (the "Web application" one).
3. Under **Authorized redirect URIs**, add:
   `https://YOUR-CLOUDFLARE-DOMAIN/auth/callback`
   (You'll know your exact Cloudflare domain after step C — come back and fill this in once you have it. It'll look like `https://asset-tracker.pages.dev/auth/callback`, or your own custom domain if you set one up.)
4. On the same page, note down the **Client Secret** (click to reveal/copy) alongside the Client ID you already have. Unlike before, this app now needs the secret too — but it stays on the server, never in any file you upload anywhere public.
5. The **Authorized JavaScript origins** field from before isn't used by this flow — you can leave it as-is or clear it, doesn't matter either way.

Leave everything else (OAuth consent screen, scopes, Test users list) exactly as it already is.

---

## B. Get a Cloudflare account and connect your repo

1. Sign up free at **dash.cloudflare.com** if you don't have an account.
2. **Workers & Pages → Create → Pages → Connect to Git**.
3. Pick the same GitHub repo you've been using (`Asset-Tracker-Application`).
4. Build settings: this is a static site with functions, so leave the build command blank and set the output directory to `/` (root) — there's nothing to compile.
5. Deploy. Cloudflare gives you a URL like `https://asset-tracker-application.pages.dev` — this is your new app URL, replacing the GitHub Pages one.

From now on, every `git push` to this repo deploys to Cloudflare Pages automatically, the same habit you already have.

---

## C. Create the session storage (KV namespace)

This is where refresh tokens live — never in a file, never in the repo.

1. In Cloudflare dashboard: **Workers & Pages → KV → Create a namespace**. Name it `SESSIONS`.
2. Go to your Pages project → **Settings → Functions → KV namespace bindings → Add binding**.
3. Variable name: `SESSIONS` (must match exactly — this is what the code refers to). Value: pick the namespace you just created.
4. Save, and redeploy if it asks (Settings changes usually need a fresh deploy to take effect — a small "Retry deployment" button covers it).

---

## D. Add your secrets

Still in your Pages project → **Settings → Environment variables**:

| Variable | Value |
|---|---|
| `GOOGLE_CLIENT_ID` | Your existing Client ID (the same `....apps.googleusercontent.com` string from before) |
| `GOOGLE_CLIENT_SECRET` | The Client Secret from step A.4 — click "Encrypt" on this one so it's never shown again after saving |
| `APP_BASE_URL` | Your exact Cloudflare Pages URL, no trailing slash — e.g. `https://asset-tracker-application.pages.dev` |

Set these for **both** Production and Preview environments if the dashboard asks — otherwise preview deploys will break.

Redeploy once more after saving these so the functions pick them up.

---

## E. Finish the redirect URI

Now that you know your real Cloudflare URL, go back to Google Cloud Console (step A.3) and make sure the Authorized redirect URI reads exactly:

`https://YOUR-ACTUAL-DOMAIN/auth/callback`

— matching `APP_BASE_URL` from step D exactly, including `https://` and no trailing slash. This is the single most common thing to get slightly wrong; Google will reject sign-in with a `redirect_uri_mismatch` error if these don't match character-for-character.

---

## F. Try it

1. Open your Cloudflare Pages URL.
2. It should show "Checking…" briefly, then the sign-in screen.
3. Tap **Sign in with Google** — this is a real page navigation to Google and back now, not a popup. Pick an account, approve access.
4. You should land back on the home screen, connected — the pill in the header now shows your actual email address.
5. Add a project (Settings → gear icon) the same way as before — nothing changed there.

Close the app entirely and reopen it. You should **not** see a sign-in screen at all — straight to the home screen, still connected. That's the whole point of this rebuild.

---

## What changed for people using their own personal Drive

Nothing extra to set up — this was actually the reason you asked for this rebuild. Since each person now authorizes with their *own* Google account through the server (rather than a shared service-account robot), their personal Drive folders work exactly the same as the shared one: add a project, paste in the folder ID (or leave it blank for the top of their My Drive), done.

---

## The 7-day / 100-user ceiling, and how to remove it

This only matters if some of your users are on personal Gmail (not your Workspace domain) — because that forces the OAuth consent screen to stay in "External" mode rather than "Internal."

- **While in Testing status:** capped at 100 total users (added manually as Test users), and every refresh token — no matter what the server does — stops working after 7 days, requiring a fresh sign-in.
- **Once verified/published:** both limits disappear. Verification is Google's review process for apps requesting sensitive scopes (which broad Drive access counts as) — it typically takes anywhere from a few days to a few weeks, and may ask for a short demo video showing how the app uses Drive access.

If everyone ends up on your Workspace domain, this section doesn't apply at all — you could instead set the consent screen to "Internal," which has no such limits or review process, but does mean personal Gmail accounts can never sign in.
